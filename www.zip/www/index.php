<!DOCTYPE html>
<html lang="es">
	<?php	include ("head.html");?>
	<body>
		<div class="head">
	    <span class="title">Ing. JJ Lizcano</span>
	    <span class="subtitle">Directorio Trabajo Sena</span>
	  </div>
	  <div class="break"><img src="img/line-break.png"></div>
	  <?php	include ("dir.php");?>
	  <?php	include ("menu.html");?>
	  <?php	include ("pie.html");?>
	</body>
</html>